# LIC Agent Management System

A simple web-based system to manage LIC agents built with FastAPI and JavaScript.

## 📦 Features

- Add, list, and delete agents
- Frontend in plain HTML/JS
- Backend with FastAPI (Python)
- CORS-enabled for frontend-backend integration

## 🚀 Deployment

This repo is ready for 1-click deployment on [Render.com](https://render.com).

### 🔧 Backend

- Navigate to `backend/` directory.
- Upload to a GitHub repository.
- Render will automatically read `render.yaml`.

### 🌐 Frontend

- Open `frontend/index.html` locally.
- Or deploy via GitHub Pages or Netlify.