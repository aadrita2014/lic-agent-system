from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

agents_db = []

class Agent(BaseModel):
    id: int
    name: str
    phone: str
    policies_sold: int

@app.get("/agents", response_model=List[Agent])
def get_agents():
    return agents_db

@app.post("/agents")
def add_agent(agent: Agent):
    agents_db.append(agent)
    return {"message": "Agent added successfully."}

@app.delete("/agents/{agent_id}")
def delete_agent(agent_id: int):
    global agents_db
    agents_db = [a for a in agents_db if a.id != agent_id]
    return {"message": "Agent deleted successfully."}