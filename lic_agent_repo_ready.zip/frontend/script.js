async function fetchAgents() {
    const response = await fetch("https://lic-agent-management.onrender.com/agents");
    const agents = await response.json();
    const list = document.getElementById("agentList");
    list.innerHTML = "";
    agents.forEach(agent => {
        const item = document.createElement("li");
        item.textContent = `ID: ${agent.id}, Name: ${agent.name}, Phone: ${agent.phone}, Policies: ${agent.policies_sold}`;
        list.appendChild(item);
    });
}

async function addAgent(event) {
    event.preventDefault();
    const agent = {
        id: parseInt(document.getElementById("id").value),
        name: document.getElementById("name").value,
        phone: document.getElementById("phone").value,
        policies_sold: parseInt(document.getElementById("policies").value)
    };
    await fetch("https://lic-agent-management.onrender.com/agents", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(agent)
    });
    fetchAgents();
}

window.onload = fetchAgents;